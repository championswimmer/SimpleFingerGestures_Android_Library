var NAVTREE_DATA =
[ [ "in.championswimmer.sfg.lib", "in/championswimmer/sfg/lib/package-summary.html", [ [ "Interfaces", null, [ [ "SimpleFingerGestures.OnFingerGestureListener", "in/championswimmer/sfg/lib/SimpleFingerGestures.OnFingerGestureListener.html", null, "" ] ]
, "" ], [ "Classes", null, [ [ "GestureAnalyser", "in/championswimmer/sfg/lib/GestureAnalyser.html", null, "" ], [ "GestureAnalyser.GestureType", "in/championswimmer/sfg/lib/GestureAnalyser.GestureType.html", null, "" ], [ "SimpleFingerGestures", "in/championswimmer/sfg/lib/SimpleFingerGestures.html", null, "" ] ]
, "" ] ]
, "" ] ]

;

